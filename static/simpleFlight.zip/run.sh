#!/bin/bash

make
./sf
